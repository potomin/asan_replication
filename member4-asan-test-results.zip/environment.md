# Member 4 environment and provenance

Run date: 2026-11-07T17:42:09+00:00

Working directory: `/home/runner/work/asan_replication/asan_replication`

Platform: `Linux runnervm7aw5e 7.0.0-1017-azure #17~24.04.1-Ubuntu SMP PREEMPT Thu Sep 24 18:46:57 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux`

Compiler: `Ubuntu clang version 18.1.3 (1ubuntu1)`

Source file: `asan_heap_demo.cpp`

Source SHA256: `e14f21a071c472b954765828520c5494ef7a5b29747f4ec2b740e1bebe2f3ec4`

Repository HEAD before this test: `0fe08425b4e68ab8d8e86235f54dd51592a084c1`

Build command: `clang++ -std=c++17 -O0 -g -fsanitize=address -fno-omit-frame-pointer /home/runner/work/asan_replication/asan_replication/asan_heap_demo.cpp -o /tmp/asan_replication_member4_1001/asan_heap_demo `

ASAN_OPTIONS: `halt_on_error=1:abort_on_error=0:detect_leaks=0:symbolize=1`

Note: HEAD identifies the repository state before committing the new test files;
the source SHA256 identifies the exact file actually compiled.

Execution location: GitHub Actions hosted Ubuntu runner (NOT local WSL).
Workflow run ID: 42397589461
Workflow SHA: 0fe08425b4e68ab8d8e86235f54dd51592a084c1
